# Quick Commerce App

This is a simple Quick Commerce App built using HTML, CSS, and JavaScript.

## Features
- Search for products
- Filter by categories
- Add to cart and checkout
- Order tracking and location sharing

## Setup
1. Clone the repository
2. Open `index.html` in a browser

## License
This project is licensed under the MIT License.