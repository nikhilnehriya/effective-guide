const products = [
    { name: "Apples", category: "Fruits", price: 200 },
    { name: "Milk", category: "Dairy", price: 150 },
    { name: "Bread", category: "Groceries", price: 250 },
    { name: "Chips", category: "Snacks", price: 100 }
];

function displayProducts() {
    const productContainer = document.getElementById("products");
    productContainer.innerHTML = "";
    products.forEach(product => {
        const div = document.createElement("div");
        div.classList.add("product");
        div.innerHTML = `<p>${product.name} - ₹${product.price}</p>
                        <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>`;
        productContainer.appendChild(div);
    });
}

window.onload = displayProducts;